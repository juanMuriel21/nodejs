console.log(`¡Hola ${nombre}! Bienvenido/a.`);
}


saludo("Juan");

